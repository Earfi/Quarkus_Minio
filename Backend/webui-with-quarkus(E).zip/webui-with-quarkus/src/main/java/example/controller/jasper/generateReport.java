package example.controller.jasper;

import example.dto.ReportDto;
import example.service.jasper.ReportService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@Path("/api/v1/report")
public class generateReport {
    @Inject
    ReportService reportService;

    @POST
    @Path("/generate/{filename}/{bucket}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces("application/pdf")
    public Response generateReport(@Valid ReportDto reportDto ,@PathParam("filename") String filename,@PathParam("bucket")String bucket) throws Exception {
        String fileName = filename+".pdf";
        byte[] pdfBytes = reportService.generatePdfReport(reportDto,fileName,bucket);
        return Response.ok(pdfBytes, "application/pdf")
                .header("Content-Disposition", "inline; filename=\""+ fileName +"\"")
                .build();
    }
}
